import React from 'react';
import { Navigate } from 'react-router-dom';
import jwt_decode from 'jwt-decode';

interface ProtectedRouteProps {
    children: JSX.Element;
    roles?: number[]; // 1 = Job Seeker, 2 = Agency
}

interface DecodedToken {
    UserID: number;
    iat: number;
    exp: number;
    UserType: number;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, roles }) => {
    const token = localStorage.getItem('token');

    if (!token) {
        return <Navigate to="/login" />;
    }

    try {
        const decoded: DecodedToken = jwt_decode(token);
        if (roles && !roles.includes(decoded.UserType)) {
            return <Navigate to="/dashboard" />;
        }
    } catch (error) {
        return <Navigate to="/login" />;
    }

    return children;
};

export default ProtectedRoute;
