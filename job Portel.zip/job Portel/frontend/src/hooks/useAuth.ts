import { useMutation, useQuery } from 'react-query';
import api from '../services/api';
import jwt_decode from 'jwt-decode';

interface LoginData {
    Email: string;
    Password: string;
}

interface RegisterData {
    FirstName: string;
    LastName: string;
    Email: string;
    PhoneNumber: string;
    Gender: string;
    UserType: number;
    Hobbies?: string[];
    AssociatedAgencyID?: number;
}

interface DecodedToken {
    UserID: number;
    iat: number;
    exp: number;
    UserType: number;
}

export const useLogin = () => {
    return useMutation(async (data: LoginData) => {
        const response = await api.post('/auth/login', data);
        const decoded: DecodedToken = jwt_decode(response.data.token);
        return { ...response.data, decoded };
    });
};

// Other hooks remain the same
