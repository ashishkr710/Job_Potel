import { useQuery } from 'react-query';
import api from '../services/api';

interface Agency {
    UserID: number;
    FirstName: string;
    LastName: string;
    AgencyName: string;
}

export const useFetchAgencies = () => {
    return useQuery<Agency[]>('agencies', async () => {
        const response = await api.get('/users/dashboard');
        return response.data.agencies;
    });
};
