import React from 'react';
import { Formik, Form, Field, ErrorMessage, FormikHelpers } from 'formik';
import * as Yup from 'yup';
import { useLogin } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { Alert, Button, Form as BootstrapForm } from 'react-bootstrap';

interface LoginFormValues {
    Email: string;
    Password: string;
}

const LoginPage: React.FC = () => {
    const navigate = useNavigate();
    const { mutate: login, isLoading, error, data } = useLogin();

    const initialValues: LoginFormValues = {
        Email: '',
        Password: '',
    };

    const validationSchema = Yup.object().shape({
        Email: Yup.string().email('Invalid email').required('Email is required'),
        Password: Yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
    });

    const onSubmit = (values: LoginFormValues, actions: FormikHelpers<LoginFormValues>) => {
        login(values, {
            onSuccess: (res) => {
                localStorage.setItem('token', res.token);
                if (res.isFirstLogin) {
                    navigate('/reset-password');
                } else {
                    navigate('/dashboard');
                }
            },
        });
    };

    return (
        <div className="container mt-5">
            <h2>Login</h2>
            {error && <Alert variant="danger">Login failed. Please check your credentials.</Alert>}
            <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
                {() => (
                    <Form>
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Email</BootstrapForm.Label>
                            <Field name="Email" type="email" className="form-control" />
                            <ErrorMessage name="Email" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Password</BootstrapForm.Label>
                            <Field name="Password" type="password" className="form-control" />
                            <ErrorMessage name="Password" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <Button variant="primary" type="submit" disabled={isLoading}>
                            {isLoading ? 'Logging in...' : 'Login'}
                        </Button>
                    </Form>
                )}
            </Formik>
        </div>
    );
};

export default LoginPage;
