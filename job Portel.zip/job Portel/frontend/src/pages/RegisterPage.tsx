import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage, FormikHelpers } from 'formik';
import * as Yup from 'yup';
import { useRegister, useFetchAgencies } from '../hooks/useAuth';
import { useQueryClient } from 'react-query';
import { Alert, Button, Form as BootstrapForm } from 'react-bootstrap';

interface RegisterFormValues {
    FirstName: string;
    LastName: string;
    Email: string;
    PhoneNumber: string;
    Gender: string;
    UserType: number;
    Hobbies: string[];
    AssociatedAgencyID?: number;
    resume?: File;
    profilePicture?: File;
}

const RegisterPage: React.FC = () => {
    const [userType, setUserType] = useState<number>(1);
    const { mutate: register, isLoading, error, data } = useRegister();
    const queryClient = useQueryClient();
    const { data: agencies } = useFetchAgencies();

    const initialValues: RegisterFormValues = {
        FirstName: '',
        LastName: '',
        Email: '',
        PhoneNumber: '',
        Gender: '',
        UserType: 1,
        Hobbies: [],
        AssociatedAgencyID: undefined,
        resume: undefined,
        profilePicture: undefined,
    };

    const validationSchema = Yup.object().shape({
        FirstName: Yup.string().required('First Name is required'),
        LastName: Yup.string().required('Last Name is required'),
        Email: Yup.string().email('Invalid email').required('Email is required'),
        PhoneNumber: Yup.string()
            .matches(/^[0-9]{10}$/, 'Phone Number must be 10 digits')
            .required('Phone Number is required'),
        Gender: Yup.string().oneOf(['Male', 'Female', 'Other']).required('Gender is required'),
        UserType: Yup.number().oneOf([1, 2]).required('User Type is required'),
        Hobbies: Yup.array().of(Yup.string().oneOf(['Sports', 'Dance', 'Singing', 'Reading'])),
        AssociatedAgencyID: Yup.number().when('UserType', {
            is: 1,
            then: Yup.number().required('Agency is required for Job Seekers'),
            otherwise: Yup.number().notRequired(),
        }),
        resume: Yup.mixed().when('UserType', {
            is: 1,
            then: Yup.mixed().required('Resume is required'),
            otherwise: Yup.mixed().notRequired(),
        }),
        profilePicture: Yup.mixed().when('UserType', {
            is: 1,
            then: Yup.mixed().required('Profile Picture is required'),
            otherwise: Yup.mixed().notRequired(),
        }),
    });

    const onSubmit = (values: RegisterFormValues, actions: FormikHelpers<RegisterFormValues>) => {
        const formData = new FormData();
        formData.append('FirstName', values.FirstName);
        formData.append('LastName', values.LastName);
        formData.append('Email', values.Email);
        formData.append('PhoneNumber', values.PhoneNumber);
        formData.append('Gender', values.Gender);
        formData.append('UserType', values.UserType.toString());
        if (values.Hobbies.length > 0) {
            values.Hobbies.forEach(hobby => formData.append('Hobbies', hobby));
        }
        if (values.UserType === 1 && values.AssociatedAgencyID) {
            formData.append('AssociatedAgencyID', values.AssociatedAgencyID.toString());
        }
        if (values.resume) {
            formData.append('resume', values.resume);
        }
        if (values.profilePicture) {
            formData.append('profilePicture', values.profilePicture);
        }

        register(formData, {
            onSuccess: () => {
                actions.resetForm();
            },
        });
    };

    return (
        <div className="container mt-5">
            <h2>Register</h2>
            {data && <Alert variant="success">{data.message}</Alert>}
            {error && <Alert variant="danger">Registration failed. Please try again.</Alert>}
            <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
                {({ values, setFieldValue }) => (
                    <Form>
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>First Name</BootstrapForm.Label>
                            <Field name="FirstName" className="form-control" />
                            <ErrorMessage name="FirstName" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Last Name</BootstrapForm.Label>
                            <Field name="LastName" className="form-control" />
                            <ErrorMessage name="LastName" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Email</BootstrapForm.Label>
                            <Field name="Email" type="email" className="form-control" />
                            <ErrorMessage name="Email" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Phone Number</BootstrapForm.Label>
                            <Field name="PhoneNumber" className="form-control" />
                            <ErrorMessage name="PhoneNumber" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Gender</BootstrapForm.Label>
                            <Field as="select" name="Gender" className="form-control">
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </Field>
                            <ErrorMessage name="Gender" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>User Type</BootstrapForm.Label>
                            <Field as="select" name="UserType" className="form-control" onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                                const value = parseInt(e.target.value);
                                setUserType(value);
                                setFieldValue('UserType', value);
                                if (value === 2) {
                                    setFieldValue('AssociatedAgencyID', undefined);
                                }
                            }}>
                                <option value={1}>Job Seeker</option>
                                <option value={2}>Agency</option>
                            </Field>
                            <ErrorMessage name="UserType" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {userType === 1 && (
                            <>
                                <BootstrapForm.Group className="mb-3">
                                    <BootstrapForm.Label>Select Agency</BootstrapForm.Label>
                                    <Field as="select" name="AssociatedAgencyID" className="form-control">
                                        <option value="">Select Agency</option>
                                        {agencies && agencies.map((agency: any) => (
                                            <option key={agency.UserID} value={agency.UserID}>{agency.AgencyName}</option>
                                        ))}
                                    </Field>
                                    <ErrorMessage name="AssociatedAgencyID" component="div" className="text-danger" />
                                </BootstrapForm.Group>

                                <BootstrapForm.Group className="mb-3">
                                    <BootstrapForm.Label>Resume</BootstrapForm.Label>
                                    <input
                                        name="resume"
                                        type="file"
                                        accept=".pdf,.doc,.docx"
                                        className="form-control"
                                        onChange={(event) => {
                                            if (event.currentTarget.files) {
                                                setFieldValue('resume', event.currentTarget.files[0]);
                                            }
                                        }}
                                    />
                                    <ErrorMessage name="resume" component="div" className="text-danger" />
                                </BootstrapForm.Group>

                                <BootstrapForm.Group className="mb-3">
                                    <BootstrapForm.Label>Profile Picture</BootstrapForm.Label>
                                    <input
                                        name="profilePicture"
                                        type="file"
                                        accept="image/*"
                                        className="form-control"
                                        onChange={(event) => {
                                            if (event.currentTarget.files) {
                                                setFieldValue('profilePicture', event.currentTarget.files[0]);
                                            }
                                        }}
                                    />
                                    <ErrorMessage name="profilePicture" component="div" className="text-danger" />
                                </BootstrapForm.Group>
                            </>
                        )}

                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Hobbies</BootstrapForm.Label>
                            <div role="group" aria-labelledby="checkbox-group">
                                <label>
                                    <Field type="checkbox" name="Hobbies" value="Sports" />
                                    Sports
                                </label>
                                <label className="ms-3">
                                    <Field type="checkbox" name="Hobbies" value="Dance" />
                                    Dance
                                </label>
                                <label className="ms-3">
                                    <Field type="checkbox" name="Hobbies" value="Singing" />
                                    Singing
                                </label>
                                <label className="ms-3">
                                    <Field type="checkbox" name="Hobbies" value="Reading" />
                                    Reading
                                </label>
                            </div>
                            <ErrorMessage name="Hobbies" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <Button variant="primary" type="submit" disabled={isLoading}>
                            {isLoading ? 'Registering...' : 'Register'}
                        </Button>
                    </Form>
                )}
            </Formik>
        </div>
    );
};

export default RegisterPage;
